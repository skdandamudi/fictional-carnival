import { NextResponse } from "next/server";
import { clearTrendCache } from "@/lib/trends";

export const dynamic = "force-dynamic";

export async function POST() {
  clearTrendCache();
  return NextResponse.json({ ok: true });
}
