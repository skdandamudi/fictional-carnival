import { NextResponse } from "next/server";
import { getTrend, supportedTrendReports } from "@/lib/trends";

export const dynamic = "force-dynamic";

const MAX_DAYS = 90;
const MIN_DAYS = 1;

export async function GET(request: Request) {
  const url = new URL(request.url);
  const daysParam = parseInt(url.searchParams.get("days") ?? "30", 10);
  const days = Number.isFinite(daysParam)
    ? Math.min(MAX_DAYS, Math.max(MIN_DAYS, daysParam))
    : 30;

  const reportParam = url.searchParams.get("report");
  const reports = reportParam
    ? reportParam.split(",").filter((r) => supportedTrendReports().includes(r))
    : supportedTrendReports();

  if (reports.length === 0) {
    return NextResponse.json(
      { error: "No valid reports requested" },
      { status: 400 },
    );
  }

  const series = await Promise.all(reports.map((r) => getTrend(r, days)));
  return NextResponse.json({ days, series });
}
