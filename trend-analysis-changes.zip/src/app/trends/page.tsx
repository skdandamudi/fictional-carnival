import { getTrend, supportedTrendReports, type TrendSeries } from "@/lib/trends";
import TrendChart, { type ChartSeries } from "@/components/TrendChart";
import TrendControls from "@/components/TrendControls";

export const dynamic = "force-dynamic";

interface SearchParams {
  days?: string;
  reports?: string;
}

const MAX_DAYS = 90;
const MIN_DAYS = 1;

const COLORS = {
  ec2: "#e5a000",
  ec2Running: "#00a91c",
  ec2Stopped: "#d54309",
  ebs: "#00a91c",
  ebsAttached: "#005ea2",
  ebsUnattached: "#a9aeb1",
  ebsSnap: "#02bfe7",
  storage: "#8168b3",
};

const ACCOUNT_PALETTE = [
  "#005ea2",
  "#e5a000",
  "#00a91c",
  "#d54309",
  "#8168b3",
  "#02bfe7",
  "#d83933",
  "#71767a",
  "#1a4480",
  "#fa9441",
];

const REPORT_LABELS: Record<string, string> = {
  "ec2-inventory": "EC2 Instances",
  "ebs-inventory": "EBS Volumes",
  "ebs-snapshots": "EBS Snapshots",
};

function pickAccountSeries(s: TrendSeries): ChartSeries[] {
  const totals: Record<string, number> = {};
  for (const p of s.points) {
    for (const [acct, n] of Object.entries(p.accounts)) {
      totals[acct] = (totals[acct] || 0) + n;
    }
  }
  const top = Object.entries(totals)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 6)
    .map(([acct]) => acct);

  return top.map((acct, i) => ({
    key: acct,
    label: acct,
    color: ACCOUNT_PALETTE[i % ACCOUNT_PALETTE.length],
    data: s.points.map((p) => ({ date: p.date, value: p.accounts[acct] ?? 0 })),
  }));
}

function delta(s: TrendSeries, metric: string): { first: number; last: number; diff: number } {
  if (s.points.length === 0) return { first: 0, last: 0, diff: 0 };
  const first = s.points[0].values[metric] ?? 0;
  const last = s.points[s.points.length - 1].values[metric] ?? 0;
  return { first, last, diff: last - first };
}

function deltaBadge(diff: number, unit = ""): string {
  if (diff === 0) return `±0${unit}`;
  const sign = diff > 0 ? "+" : "";
  return `${sign}${diff.toLocaleString()}${unit}`;
}

function deltaClass(diff: number): string {
  if (diff > 0) return "trend-delta trend-delta-up";
  if (diff < 0) return "trend-delta trend-delta-down";
  return "trend-delta trend-delta-flat";
}

export default async function TrendsPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const sp = await searchParams;
  const parsedDays = parseInt(sp.days ?? "30", 10);
  const days = Number.isFinite(parsedDays)
    ? Math.min(MAX_DAYS, Math.max(MIN_DAYS, parsedDays))
    : 30;

  const supported = supportedTrendReports();
  const requested = (sp.reports ?? supported.join(","))
    .split(",")
    .map((r) => r.trim())
    .filter((r) => supported.includes(r));
  const reports = requested.length > 0 ? requested : supported;

  const series = await Promise.all(reports.map((r) => getTrend(r, days)));
  const byReport = new Map(series.map((s) => [s.report, s]));

  const ec2 = byReport.get("ec2-inventory");
  const ebs = byReport.get("ebs-inventory");
  const snap = byReport.get("ebs-snapshots");

  const totalSeries: ChartSeries[] = [];
  if (ec2) {
    totalSeries.push({
      key: "ec2",
      label: "EC2 Instances",
      color: COLORS.ec2,
      data: ec2.points.map((p) => ({ date: p.date, value: p.values.total ?? 0 })),
    });
  }
  if (ebs) {
    totalSeries.push({
      key: "ebs",
      label: "EBS Volumes",
      color: COLORS.ebs,
      data: ebs.points.map((p) => ({ date: p.date, value: p.values.total_volumes ?? 0 })),
    });
  }
  if (snap) {
    totalSeries.push({
      key: "snap",
      label: "EBS Snapshots",
      color: COLORS.ebsSnap,
      data: snap.points.map((p) => ({ date: p.date, value: p.values.total ?? 0 })),
    });
  }

  const storageSeries: ChartSeries[] = [];
  if (ec2) {
    storageSeries.push({
      key: "ec2-ebs",
      label: "EC2 Attached EBS",
      color: COLORS.ec2,
      data: ec2.points.map((p) => ({ date: p.date, value: p.values.total_ebs_gb ?? 0 })),
    });
  }
  if (ebs) {
    storageSeries.push({
      key: "ebs-gb",
      label: "EBS Volumes",
      color: COLORS.ebs,
      data: ebs.points.map((p) => ({ date: p.date, value: p.values.total_volume_gb ?? 0 })),
    });
  }
  if (snap) {
    storageSeries.push({
      key: "snap-gb",
      label: "EBS Snapshots",
      color: COLORS.ebsSnap,
      data: snap.points.map((p) => ({ date: p.date, value: p.values.total_size_gb ?? 0 })),
    });
  }

  const ec2State: ChartSeries[] = ec2
    ? [
        {
          key: "running",
          label: "Running",
          color: COLORS.ec2Running,
          data: ec2.points.map((p) => ({ date: p.date, value: p.values.running ?? 0 })),
        },
        {
          key: "stopped",
          label: "Stopped",
          color: COLORS.ec2Stopped,
          data: ec2.points.map((p) => ({ date: p.date, value: p.values.stopped ?? 0 })),
        },
      ]
    : [];

  const ebsAttach: ChartSeries[] = ebs
    ? [
        {
          key: "attached",
          label: "Attached",
          color: COLORS.ebsAttached,
          data: ebs.points.map((p) => ({
            date: p.date,
            value: p.values.attached_volumes ?? 0,
          })),
        },
        {
          key: "unattached",
          label: "Unattached",
          color: COLORS.ebsUnattached,
          data: ebs.points.map((p) => ({
            date: p.date,
            value: p.values.unattached_volumes ?? 0,
          })),
        },
      ]
    : [];

  const stats = [
    ec2
      ? { label: "EC2 Instances", report: "ec2-inventory", ...delta(ec2, "total"), unit: "" }
      : null,
    ebs
      ? {
          label: "EBS Volumes",
          report: "ebs-inventory",
          ...delta(ebs, "total_volumes"),
          unit: "",
        }
      : null,
    ebs
      ? {
          label: "EBS Storage",
          report: "ebs-inventory",
          ...delta(ebs, "total_volume_gb"),
          unit: " GB",
        }
      : null,
    snap
      ? { label: "EBS Snapshots", report: "ebs-snapshots", ...delta(snap, "total"), unit: "" }
      : null,
    snap
      ? {
          label: "Snapshot Storage",
          report: "ebs-snapshots",
          ...delta(snap, "total_size_gb"),
          unit: " GB",
        }
      : null,
  ].filter((s): s is NonNullable<typeof s> => s !== null);

  const anyData = series.some((s) => s.points.length > 0);

  return (
    <>
      <div className="page-header">
        <h2>Trend Analysis</h2>
        <p className="subtitle">
          Historical EC2, EBS, and EBS snapshot trends across the selected range.
        </p>
      </div>

      <TrendControls />

      {!anyData && (
        <div className="trend-empty-banner">
          No historical reports found for the selected range. Trends are sourced from dated S3
          report uploads (e.g. <code>reports/&lt;report&gt;/YYYY-MM-DD/...</code>); they appear
          here once at least one dated upload exists.
        </div>
      )}

      {stats.length > 0 && (
        <div className="trend-stats">
          {stats.map((s) => (
            <div key={`${s.report}-${s.label}`} className="trend-stat-card">
              <div className="trend-stat-label">{s.label}</div>
              <div className="trend-stat-value">
                {s.last.toLocaleString()}
                <span className="trend-stat-unit">{s.unit}</span>
              </div>
              <div className={deltaClass(s.diff)}>
                {deltaBadge(s.diff, s.unit)} over {days}d
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="trend-grid">
        {totalSeries.length > 0 && (
          <TrendChart title="Resource counts" series={totalSeries} />
        )}
        {storageSeries.length > 0 && (
          <TrendChart title="Storage (GB)" unit="GB" series={storageSeries} />
        )}
        {ec2State.length > 0 && (
          <TrendChart title="EC2 state (running vs stopped)" series={ec2State} />
        )}
        {ebsAttach.length > 0 && (
          <TrendChart title="EBS volumes (attached vs unattached)" series={ebsAttach} />
        )}

        {series.map((s) => {
          const acctSeries = pickAccountSeries(s);
          if (acctSeries.length === 0) return null;
          return (
            <TrendChart
              key={`${s.report}-accounts`}
              title={`${REPORT_LABELS[s.report] ?? s.report} by account (top 6)`}
              series={acctSeries}
            />
          );
        })}
      </div>
    </>
  );
}
