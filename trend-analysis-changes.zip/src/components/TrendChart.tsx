"use client";

import { useMemo, useState } from "react";

export interface ChartSeries {
  key: string;
  label: string;
  color: string;
  data: { date: string; value: number }[];
}

interface Props {
  title: string;
  unit?: string;
  series: ChartSeries[];
  height?: number;
  yFormatter?: (n: number) => string;
}

const PADDING = { top: 16, right: 16, bottom: 28, left: 48 };
const WIDTH = 720;

function formatShort(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return Math.round(n).toString();
}

function formatDateShort(d: string): string {
  const parts = d.split("-");
  if (parts.length !== 3) return d;
  return `${parts[1]}/${parts[2]}`;
}

export default function TrendChart({
  title,
  unit,
  series,
  height = 240,
  yFormatter = formatShort,
}: Props) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const { dates, yMax, plotW, plotH } = useMemo(() => {
    const dateSet = new Set<string>();
    let max = 0;
    for (const s of series) {
      for (const p of s.data) {
        dateSet.add(p.date);
        if (p.value > max) max = p.value;
      }
    }
    const sorted = Array.from(dateSet).sort();
    return {
      dates: sorted,
      yMax: max === 0 ? 1 : max * 1.1,
      plotW: WIDTH - PADDING.left - PADDING.right,
      plotH: height - PADDING.top - PADDING.bottom,
    };
  }, [series, height]);

  if (dates.length === 0) {
    return (
      <div className="trend-chart trend-chart-empty">
        <h3 className="trend-chart-title">{title}</h3>
        <p className="trend-chart-empty-msg">No historical data available for this range.</p>
      </div>
    );
  }

  const xFor = (idx: number) =>
    PADDING.left + (dates.length === 1 ? plotW / 2 : (idx / (dates.length - 1)) * plotW);
  const yFor = (v: number) => PADDING.top + plotH - (v / yMax) * plotH;

  const ticks = 4;
  const yTicks = Array.from({ length: ticks + 1 }, (_, i) => (yMax * i) / ticks);

  const xLabelStep = Math.max(1, Math.ceil(dates.length / 8));

  return (
    <div className="trend-chart">
      <div className="trend-chart-header">
        <h3 className="trend-chart-title">{title}</h3>
        <div className="trend-chart-legend">
          {series.map((s) => (
            <span key={s.key} className="trend-legend-item">
              <span className="trend-legend-swatch" style={{ background: s.color }} />
              {s.label}
            </span>
          ))}
        </div>
      </div>
      <svg
        className="trend-chart-svg"
        viewBox={`0 0 ${WIDTH} ${height}`}
        preserveAspectRatio="xMidYMid meet"
        onMouseLeave={() => setHoverIdx(null)}
      >
        {yTicks.map((t, i) => {
          const y = yFor(t);
          return (
            <g key={i}>
              <line
                x1={PADDING.left}
                x2={WIDTH - PADDING.right}
                y1={y}
                y2={y}
                className="trend-grid"
              />
              <text x={PADDING.left - 8} y={y + 4} className="trend-axis-label" textAnchor="end">
                {yFormatter(t)}
              </text>
            </g>
          );
        })}

        {dates.map((d, i) =>
          i % xLabelStep === 0 ? (
            <text
              key={d}
              x={xFor(i)}
              y={height - 8}
              className="trend-axis-label"
              textAnchor="middle"
            >
              {formatDateShort(d)}
            </text>
          ) : null,
        )}

        {series.map((s) => {
          const map = new Map(s.data.map((p) => [p.date, p.value]));
          const pts = dates.map((d, i) => {
            const v = map.get(d);
            return v === undefined ? null : { x: xFor(i), y: yFor(v) };
          });
          const segments: { x: number; y: number }[][] = [];
          let cur: { x: number; y: number }[] = [];
          for (const pt of pts) {
            if (pt) cur.push(pt);
            else if (cur.length) {
              segments.push(cur);
              cur = [];
            }
          }
          if (cur.length) segments.push(cur);

          return (
            <g key={s.key}>
              {segments.map((seg, i) => (
                <polyline
                  key={i}
                  className="trend-line"
                  points={seg.map((p) => `${p.x},${p.y}`).join(" ")}
                  style={{ stroke: s.color }}
                />
              ))}
              {pts.map((p, i) =>
                p ? (
                  <circle
                    key={i}
                    cx={p.x}
                    cy={p.y}
                    r={hoverIdx === i ? 4 : 2.5}
                    style={{ fill: s.color }}
                    className="trend-dot"
                  />
                ) : null,
              )}
            </g>
          );
        })}

        {dates.map((d, i) => (
          <rect
            key={d}
            x={xFor(i) - (plotW / Math.max(1, dates.length - 1)) / 2}
            y={PADDING.top}
            width={plotW / Math.max(1, dates.length - 1)}
            height={plotH}
            fill="transparent"
            onMouseEnter={() => setHoverIdx(i)}
          />
        ))}

        {hoverIdx !== null && (
          <line
            x1={xFor(hoverIdx)}
            x2={xFor(hoverIdx)}
            y1={PADDING.top}
            y2={PADDING.top + plotH}
            className="trend-hover-line"
          />
        )}
      </svg>

      {hoverIdx !== null && (
        <div className="trend-tooltip">
          <strong>{dates[hoverIdx]}</strong>
          {series.map((s) => {
            const v = s.data.find((p) => p.date === dates[hoverIdx])?.value;
            return (
              <div key={s.key} className="trend-tooltip-row">
                <span className="trend-legend-swatch" style={{ background: s.color }} />
                <span>{s.label}:</span>
                <strong>
                  {v === undefined ? "—" : yFormatter(v)}
                  {unit ? ` ${unit}` : ""}
                </strong>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
