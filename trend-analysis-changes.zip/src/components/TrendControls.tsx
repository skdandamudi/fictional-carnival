"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState, useTransition } from "react";

const RANGES = [
  { days: 7, label: "7d" },
  { days: 14, label: "14d" },
  { days: 30, label: "30d" },
  { days: 60, label: "60d" },
  { days: 90, label: "90d" },
];

const REPORTS = [
  { name: "ec2-inventory", label: "EC2" },
  { name: "ebs-inventory", label: "EBS Volumes" },
  { name: "ebs-snapshots", label: "EBS Snapshots" },
];

export default function TrendControls() {
  const router = useRouter();
  const params = useSearchParams();
  const [pending, startTransition] = useTransition();
  const [refreshing, setRefreshing] = useState(false);
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);

  const days = parseInt(params.get("days") ?? "30", 10);
  const selected = new Set(
    (params.get("reports") ?? REPORTS.map((r) => r.name).join(","))
      .split(",")
      .filter(Boolean),
  );

  const update = (next: URLSearchParams) => {
    startTransition(() => {
      router.replace(`/trends?${next.toString()}`);
    });
  };

  const setDays = (d: number) => {
    const next = new URLSearchParams(params.toString());
    next.set("days", String(d));
    update(next);
  };

  const toggleReport = (name: string) => {
    const next = new URLSearchParams(params.toString());
    const set = new Set(selected);
    if (set.has(name)) set.delete(name);
    else set.add(name);
    if (set.size === 0) return;
    next.set("reports", Array.from(set).join(","));
    update(next);
  };

  const refresh = async () => {
    if (refreshing) return;
    setRefreshing(true);
    try {
      await fetch("/api/trends/refresh", { method: "POST" });
    } catch (err) {
      console.error("Trend refresh failed:", err);
    }
    setLastRefreshed(new Date());
    startTransition(() => {
      router.refresh();
      setRefreshing(false);
    });
  };

  return (
    <div className="trend-controls">
      <div className="trend-control-group">
        <span className="trend-control-label">Range</span>
        {RANGES.map((r) => (
          <button
            key={r.days}
            type="button"
            className={`trend-chip ${days === r.days ? "active" : ""}`}
            onClick={() => setDays(r.days)}
            disabled={pending}
          >
            {r.label}
          </button>
        ))}
      </div>
      <div className="trend-control-group">
        <span className="trend-control-label">Resources</span>
        {REPORTS.map((r) => (
          <button
            key={r.name}
            type="button"
            className={`trend-chip ${selected.has(r.name) ? "active" : ""}`}
            onClick={() => toggleReport(r.name)}
            disabled={pending}
          >
            {r.label}
          </button>
        ))}
      </div>
      <div className="trend-control-group trend-control-refresh">
        <button
          type="button"
          className="trend-chip trend-chip-action"
          onClick={refresh}
          disabled={refreshing || pending}
          title="Clear cache and reload trend data from S3"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            className={`trend-refresh-icon ${refreshing ? "spinning" : ""}`}
          >
            <polyline points="23 4 23 10 17 10" />
            <polyline points="1 20 1 14 7 14" />
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
          </svg>
          {refreshing ? "Refreshing…" : "Refresh"}
        </button>
        {lastRefreshed && !refreshing && (
          <span className="trend-control-pending">
            Updated {lastRefreshed.toLocaleTimeString()}
          </span>
        )}
      </div>
      {pending && !refreshing && (
        <span className="trend-control-pending">Loading…</span>
      )}
    </div>
  );
}
