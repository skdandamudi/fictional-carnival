import { config } from "./config";
import fs from "fs";
import path from "path";

export interface TrendPoint {
  date: string;
  values: Record<string, number>;
  accounts: Record<string, number>;
}

export interface TrendSeries {
  report: string;
  metrics: string[];
  points: TrendPoint[];
}

interface CacheEntry {
  data: TrendSeries;
  cachedAt: number;
}

const cache = new Map<string, CacheEntry>();

const METRIC_KEYS: Record<string, string[]> = {
  "ec2-inventory": ["total", "running", "stopped", "total_ebs_gb"],
  "ebs-inventory": [
    "total_volumes",
    "total_volume_gb",
    "attached_volumes",
    "unattached_volumes",
  ],
  "ebs-snapshots": ["total", "total_size_gb"],
};

const ITEM_KEYS: Record<string, string> = {
  "ec2-inventory": "instances",
  "ebs-inventory": "volumes",
  "ebs-snapshots": "snapshots",
};

export function supportedTrendReports(): string[] {
  return Object.keys(METRIC_KEYS);
}

export function metricsForReport(report: string): string[] {
  return METRIC_KEYS[report] ?? [];
}

function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function rangeDates(days: number): string[] {
  const out: string[] = [];
  const today = new Date();
  today.setUTCHours(0, 0, 0, 0);
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setUTCDate(today.getUTCDate() - i);
    out.push(isoDate(d));
  }
  return out;
}

function extractMetrics(
  report: string,
  data: Record<string, unknown>,
): { values: Record<string, number>; accounts: Record<string, number> } {
  const keys = METRIC_KEYS[report] ?? [];
  const values: Record<string, number> = {};
  for (const k of keys) {
    const v = data[k];
    values[k] = typeof v === "number" ? v : 0;
  }

  const accounts: Record<string, number> = {};
  const itemKey = ITEM_KEYS[report];
  const items = itemKey ? data[itemKey] : undefined;
  if (Array.isArray(items)) {
    for (const item of items) {
      const name = (item as Record<string, unknown>).account_name;
      if (typeof name === "string") {
        accounts[name] = (accounts[name] || 0) + 1;
      }
    }
  }
  return { values, accounts };
}

async function listDailyKeysS3(report: string, days: number): Promise<Map<string, string>> {
  const { S3Client, ListObjectsV2Command } = await import("@aws-sdk/client-s3");
  const client = new S3Client({ region: config.s3Region });
  const prefix = `${config.s3Prefix}/${report}/`;
  const wanted = new Set(rangeDates(days));

  const keysByDate = new Map<string, string>();
  let continuationToken: string | undefined;

  do {
    const resp = await client.send(
      new ListObjectsV2Command({
        Bucket: config.s3Bucket,
        Prefix: prefix,
        ContinuationToken: continuationToken,
      }),
    );
    for (const obj of resp.Contents ?? []) {
      const key = obj.Key;
      if (!key || !key.endsWith(`.json`)) continue;
      const rel = key.slice(prefix.length);
      if (rel.startsWith("latest/")) continue;
      const slash = rel.indexOf("/");
      if (slash <= 0) continue;
      const date = rel.slice(0, slash);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !wanted.has(date)) continue;
      const existing = keysByDate.get(date);
      if (!existing || key > existing) keysByDate.set(date, key);
    }
    continuationToken = resp.IsTruncated ? resp.NextContinuationToken : undefined;
  } while (continuationToken);

  return keysByDate;
}

async function fetchJsonS3(key: string): Promise<Record<string, unknown> | null> {
  try {
    const { S3Client, GetObjectCommand } = await import("@aws-sdk/client-s3");
    const client = new S3Client({ region: config.s3Region });
    const resp = await client.send(
      new GetObjectCommand({ Bucket: config.s3Bucket, Key: key }),
    );
    const body = await resp.Body?.transformToString();
    if (!body) return null;
    return JSON.parse(body);
  } catch (err) {
    console.error(`Failed to fetch s3://${config.s3Bucket}/${key}:`, err);
    return null;
  }
}

async function loadFromS3(report: string, days: number): Promise<TrendPoint[]> {
  const keysByDate = await listDailyKeysS3(report, days);
  const entries = Array.from(keysByDate.entries()).sort(([a], [b]) =>
    a.localeCompare(b),
  );

  const points: TrendPoint[] = [];
  const concurrency = 8;
  for (let i = 0; i < entries.length; i += concurrency) {
    const batch = entries.slice(i, i + concurrency);
    const results = await Promise.all(
      batch.map(async ([date, key]) => {
        const data = await fetchJsonS3(key);
        if (!data) return null;
        const { values, accounts } = extractMetrics(report, data);
        return { date, values, accounts } satisfies TrendPoint;
      }),
    );
    for (const r of results) if (r) points.push(r);
  }
  return points;
}

function loadFromLocal(report: string, days: number): TrendPoint[] {
  const dir = path.resolve(config.localReportDir, "history", report);
  const wanted = new Set(rangeDates(days));
  const points: TrendPoint[] = [];

  if (fs.existsSync(dir)) {
    for (const file of fs.readdirSync(dir)) {
      const m = file.match(/^(\d{4}-\d{2}-\d{2})\.json$/);
      if (!m || !wanted.has(m[1])) continue;
      try {
        const data = JSON.parse(fs.readFileSync(path.join(dir, file), "utf-8"));
        const { values, accounts } = extractMetrics(report, data);
        points.push({ date: m[1], values, accounts });
      } catch (err) {
        console.error(`Failed to read ${file}:`, err);
      }
    }
  }

  if (points.length === 0) {
    const latest = path.resolve(config.localReportDir, `${report}.json`);
    if (fs.existsSync(latest)) {
      try {
        const data = JSON.parse(fs.readFileSync(latest, "utf-8"));
        const { values, accounts } = extractMetrics(report, data);
        const rawDate = data.report_date;
        const date =
          typeof rawDate === "string" && /^\d{4}-\d{2}-\d{2}/.test(rawDate)
            ? rawDate.slice(0, 10)
            : isoDate(new Date());
        points.push({ date, values, accounts });
      } catch (err) {
        console.error(`Failed to read ${latest}:`, err);
      }
    }
  }

  return points.sort((a, b) => a.date.localeCompare(b.date));
}

export async function getTrend(report: string, days: number): Promise<TrendSeries> {
  const metrics = METRIC_KEYS[report];
  if (!metrics) {
    return { report, metrics: [], points: [] };
  }

  const cacheKey = `trend:${report}:${days}`;
  const cached = cache.get(cacheKey);
  if (cached && Date.now() - cached.cachedAt < config.cacheTtlSeconds * 1000) {
    return cached.data;
  }

  let points: TrendPoint[];
  if (config.dataSource === "local" || !config.s3Bucket) {
    points = loadFromLocal(report, days);
  } else {
    try {
      points = await loadFromS3(report, days);
    } catch (err) {
      console.error(`Trend S3 load failed for ${report}:`, err);
      points = [];
    }
  }

  const series: TrendSeries = { report, metrics, points };
  cache.set(cacheKey, { data: series, cachedAt: Date.now() });
  return series;
}

export function clearTrendCache() {
  cache.clear();
}
